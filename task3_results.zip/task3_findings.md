# Task 3: Improvement and validation


### Findings: baseline vs improved Linear SVM

**Headline.** Test macro-F1 moved from **0.599** to **0.610** (+0.011, +1.8% relative); accuracy 0.791 to 0.772, macro ROC-AUC 0.836 to 0.835, MCC 0.565 to 0.542. The improvement is **statistically meaningful**: the bootstrap interval excludes 0 and cross-validation agrees.

**What was changed.** Feature set chosen by cross-validation: *2 + char n-grams*. Hyperparameters: {'clf__C': 0.5, 'features__word__ngram_range': (1, 3)}. Class-score offsets (neg, neu, pos): [-0.091, 0.274, 0.0].

**Evidence.**
- Paired 5-fold CV macro-F1: 0.594 vs 0.600; improved wins 5/5 folds (paired t-test p = 0.006).
- Paired bootstrap on the test set: difference +0.0111, 95% CI [+0.0005, +0.0218].
- McNemar: improved fixed 323 reviews and broke 497 (p = 0.000).
- Unseen drugs: 0.590 vs 0.592 (+0.002), so the gain holds on drugs not seen in training.
- Per class, F1 changed most for **neutral** (+0.056) and least for **negative** (-0.016).
- Largest single stage gain in the ablation (CV): **1 + negation marking**.

**Cost.** Training time 11.8s to 75.1s; features per model: 126,316 (improved).

**Interpretation.** Negation marking helps because phrases like "not helpful" or "no relief" now have their own features instead of being confused with their positive counterparts. Character n-grams help with misspellings and informal wording in patient text. The text-statistic and side-effect features add a little extra signal but are weak on their own, since a patient can mention side effects and still rate the drug highly. The neutral class (ratings 5-6) remains the hardest: its wording overlaps with both neighbours, and the ratings are only a noisy proxy for sentiment.

**Limitations.** Gains are measured against labels derived from ratings; the lexicon covers only listed side effects; CV compares the models without the class offsets (offsets are evaluated on the test set only); results come from 44,852 reviews.


## Test-set comparison

|                   |   accuracy |   balanced_acc |   macro_precision |   macro_recall |   macro_F1 |   weighted_F1 |   macro_ROC_AUC |     MCC |   fit_time_s |
|:------------------|-----------:|---------------:|------------------:|---------------:|-----------:|--------------:|----------------:|--------:|-------------:|
| Baseline (Task 2) |     0.791  |         0.5985 |            0.6069 |         0.5985 |     0.5991 |        0.7812 |          0.8365 |  0.5655 |      11.7727 |
| Improved (Task 3) |     0.7716 |         0.612  |            0.6109 |         0.612  |     0.6101 |        0.7774 |          0.8354 |  0.5424 |      75.076  |
| Change            |    -0.0194 |         0.0136 |            0.004  |         0.0136 |     0.011  |       -0.0038 |         -0.001  | -0.023  |      63.3033 |

## Feature ablation

| stage                                |   CV_macro_F1 |   CV_std |   test_macro_F1 |
|:-------------------------------------|--------------:|---------:|----------------:|
| 0 Baseline: raw words                |        0.5864 |   0.0012 |          0.5991 |
| 1 + negation marking                 |        0.5934 |   0.0031 |          0.6066 |
| 2 + char n-grams                     |        0.5937 |   0.0037 |          0.602  |
| 3 + text-stat & side-effect features |        0.5935 |   0.0037 |          0.5979 |

## Paired cross-validation

|        |   baseline |   improved |   difference |
|:-------|-----------:|-----------:|-------------:|
| fold 1 |     0.5877 |     0.5981 |       0.0104 |
| fold 2 |     0.6003 |     0.6039 |       0.0036 |
| fold 3 |     0.5883 |     0.5954 |       0.007  |
| fold 4 |     0.5895 |     0.5938 |       0.0043 |
| fold 5 |     0.6019 |     0.6102 |       0.0083 |
| mean   |     0.5935 |     0.6003 |       0.0067 |
| std    |     0.0069 |     0.0068 |       0.0028 |
